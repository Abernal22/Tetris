module Main where

import System.IO (hSetBuffering, BufferMode(NoBuffering), stdout)
import Control.Concurrent (threadDelay)

main :: IO ()
main = do
  hSetBuffering stdout NoBuffering
  putStrLn "Welcome to Tetris in Haskell!"
  gameLoop 


gameLoop :: IO () 
gameLoop = do 
    putStrLn "Game loop tick"
    threadDelay 1000000 -- 1 second delay
    gameLoop 
